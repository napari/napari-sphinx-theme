# napari-sphinx-theme

A Sphinx theme fork of the awesome
[pydata-sphinx-theme](https://github.com/pydata/pydata-sphinx-theme)  with the
look and feel of napari.

This is currently a work-in-progress, but since it's a fork of pydata, all the
existing configurations and affordances are already available. Check out the
[PyData Docs](https://pydata-sphinx-theme.readthedocs.io/en/latest/) for more
info.
