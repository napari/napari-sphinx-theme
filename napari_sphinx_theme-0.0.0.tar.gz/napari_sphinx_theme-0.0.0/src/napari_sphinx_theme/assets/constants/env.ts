export const BUILD_PROD = process.env.NODE_ENV === 'production';

export const PROD = process.env.ENV === 'prod';

export const STAGING = process.env.ENV === 'staging';
