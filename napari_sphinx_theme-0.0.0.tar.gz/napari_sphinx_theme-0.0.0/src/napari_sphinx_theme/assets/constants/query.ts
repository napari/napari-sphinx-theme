export const SEARCH_QUERY_PARAM = 'q';
