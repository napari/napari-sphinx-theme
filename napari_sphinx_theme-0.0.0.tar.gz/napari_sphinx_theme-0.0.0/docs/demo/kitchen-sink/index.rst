.. DOWNLOADED FROM sphinx-themes.org, DO NOT MANUALLY EDIT
============
Kitchen Sink
============

This section showcases the various elements that Sphinx supports out-of-the-box.

.. toctree::

  paragraph-markup
  api
  lists-and-tables
