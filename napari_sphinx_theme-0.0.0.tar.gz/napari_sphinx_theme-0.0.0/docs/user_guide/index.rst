==========
User Guide
==========


.. toctree::
   :maxdepth: 2

   install
   configuring
   sections
   customizing
   accessibility

.. meta::
    :description lang=en:
        Documentation for users who wish to build sphinx sites with
        pydata-sphinx-theme.
