Section 1 index
===============

.. toctree::
   :caption: Section 1

   subsection1/index
   page2
