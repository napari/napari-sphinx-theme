test-navbar-in-page-headers
===========================

.. toctree::

   page1
   page2
