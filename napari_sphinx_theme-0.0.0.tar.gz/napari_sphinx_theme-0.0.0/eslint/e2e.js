module.exports = {
  extends: [require.resolve('./jest'), 'plugin:jest-playwright/recommended'],
};
