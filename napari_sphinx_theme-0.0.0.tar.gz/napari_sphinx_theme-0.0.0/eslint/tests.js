module.exports = {
  extends: [require.resolve('./jest')],
};
