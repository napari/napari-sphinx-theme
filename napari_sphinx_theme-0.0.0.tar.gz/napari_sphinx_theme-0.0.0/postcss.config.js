module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    // 'postcss-import': {},
    'postcss-strip-units': {},
  },
};
